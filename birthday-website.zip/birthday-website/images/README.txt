Put her photos here, named photo1.jpg ... photo7.jpg
(lowercase names, please - GitHub Pages is case-sensitive).
Portrait photos work best; they are cropped to 4:5 automatically.
